import { MouseHoverDirective } from './mouse-hover.directive';

describe('MouseHoverDirective', () => {
  it('should create an instance', () => {
    const directive = new MouseHoverDirective();
    expect(directive).toBeTruthy();
  });
});
